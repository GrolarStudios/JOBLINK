class KomandaCashClose {
  final String id;
  final DateTime openedAt;
  final DateTime closedAt;
  final double cashTotal;
  final double cardTotal;
  final double transferTotal;
  final double tipsTotal;
  final double expectedTotal;
  final double countedCash;
  final double difference;
  final int paidOrders;
  final String notes;
  const KomandaCashClose({required this.id,required this.openedAt,required this.closedAt,required this.cashTotal,required this.cardTotal,required this.transferTotal,required this.tipsTotal,required this.expectedTotal,required this.countedCash,required this.difference,required this.paidOrders,this.notes=''});
}
