import '../../domain/entities/komanda_order.dart';
import '../../domain/entities/komanda_ticket_config.dart';
import 'komanda_ticket_print_service.dart';

/// Impresión automática al terminar de crear un pedido.
///
/// Ya no existe un ticket especial de cocina dentro de este flujo. Siempre se
/// imprime el ticket general configurado del restaurante.
class KomandaKitchenPrintService {
  const KomandaKitchenPrintService._();

  static bool _printing = false;

  static Future<bool> printOrder(
    KomandaOrder order,
    KomandaTicketConfig config,
  ) async {
    if (_printing) return false;
    _printing = true;

    try {
      await KomandaTicketPrintService.printOrder(order, config);
      return true;
    } catch (_) {
      return false;
    } finally {
      _printing = false;
    }
  }
}
