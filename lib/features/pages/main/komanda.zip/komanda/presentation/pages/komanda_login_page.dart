import 'package:flutter/material.dart';

import '../../core/komanda_theme.dart';
import '../widgets/komanda_widgets.dart';

class KomandaLoginPage extends StatefulWidget {
  final Future<KomandaLoginResult> Function(String username, String password)
      onLogin;

  const KomandaLoginPage({
    super.key,
    required this.onLogin,
  });

  @override
  State<KomandaLoginPage> createState() => _KomandaLoginPageState();
}

class KomandaLoginResult {
  final bool success;
  final bool offline;
  final String? message;

  const KomandaLoginResult({
    required this.success,
    this.offline = false,
    this.message,
  });
}

class _KomandaLoginPageState extends State<KomandaLoginPage> {
  final _user = TextEditingController();
  final _password = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  String? _error;

  Future<void> _login() async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await widget.onLogin(
      _user.text.trim(),
      _password.text,
    );
    if (!mounted) return;

    if (!result.success) {
      setState(() {
        _loading = false;
        _error = result.message ?? 'Usuario o contraseña incorrectos.';
      });
      return;
    }

  }

  @override
  void dispose() {
    _user.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => KomandaPhoneFrame(
        useGlobalLoading: false,
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: KomandaCard(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 76, height: 76,
                    decoration: BoxDecoration(gradient: LinearGradient(colors:[KomandaTheme.purple, KomandaTheme.purple.withOpacity(.72)]),borderRadius:BorderRadius.circular(24)),
                    child: const Center(
                    child: Icon(Icons.restaurant_menu,color:Colors.white,size:36),
                  )),
                  const SizedBox(height: 16),
                  const Text(
                    'Grolar POS',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Inicia sesión para administrar tu restaurante',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: KomandaTheme.softText),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _user,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'Usuario',
                      prefixIcon: Icon(Icons.person_outline),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _password,
                    obscureText: _obscure,
                    onSubmitted: (_) => _login(),
                    decoration: InputDecoration(
                      labelText: 'Contraseña',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => _obscure = !_obscure),
                        icon: Icon(
                          _obscure
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                        ),
                      ),
                    ),
                  ),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(
                        _error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _loading ? null : _login,
                      icon: _loading
                          ? const SizedBox.shrink()
                          : const Icon(Icons.login),
                      label: Text(_loading ? 'Actualizando...' : 'Ingresar'),
                    ),
                  ),
                ],
              ),
            )),
          ),
        ),
      );
}
