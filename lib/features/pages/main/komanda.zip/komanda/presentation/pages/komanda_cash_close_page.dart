import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/komanda_theme.dart';
import '../../domain/entities/komanda_cash_close.dart';
import '../../domain/entities/komanda_order.dart';
import '../bloc/komanda_bloc.dart';
import '../bloc/komanda_event.dart';
import '../bloc/komanda_state.dart';
import '../widgets/komanda_widgets.dart';

class KomandaCashClosePage extends StatefulWidget {
  const KomandaCashClosePage({super.key});

  @override
  State<KomandaCashClosePage> createState() => _KomandaCashClosePageState();
}

class _KomandaCashClosePageState extends State<KomandaCashClosePage> {
  DateTime selectedDate = DateTime.now();
  String shift = DateTime.now().hour < 15 ? 'Mañana' : 'Tarde';
  final countedCashController = TextEditingController();
  final notesController = TextEditingController();

  @override
  void dispose() {
    countedCashController.dispose();
    notesController.dispose();
    super.dispose();
  }

  DateTime get shiftStart => shift == 'Mañana'
      ? DateTime(selectedDate.year, selectedDate.month, selectedDate.day, 0, 0)
      : DateTime(selectedDate.year, selectedDate.month, selectedDate.day, 15, 0);

  DateTime get shiftEnd => shift == 'Mañana'
      ? DateTime(selectedDate.year, selectedDate.month, selectedDate.day, 14, 59, 59)
      : DateTime(selectedDate.year, selectedDate.month, selectedDate.day, 23, 59, 59);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<KomandaBloc, KomandaState>(
      builder: (context, state) {
        final orders = _ordersForShift(state.orders);
        final cash = _sumByMethod(orders, 'cash');
        final card = _sumByMethod(orders, 'card');
        final transfer = _sumByMethod(orders, 'transfer');
        final tips = orders.fold<double>(0, (sum, o) => sum + o.tipAmount);
        final sales = orders.fold<double>(0, (sum, o) => sum + o.total);
        final totalCollected = sales + tips;
        final expectedCash = cash;
        final countedCash = _parseMoney(countedCashController.text);
        final difference = countedCash - expectedCash;

        final existingClose = state.cashClosures.where((close) {
          return _sameDay(close.openedAt, selectedDate) &&
              (close.openedAt.hour < 15 ? 'Mañana' : 'Tarde') == shift;
        }).toList();

        return KomandaPhoneFrame(
          child: Column(
            children: [
              KomandaHeader(
                title: 'Corte de caja',
                subtitle: 'Arqueo por fecha y turno',
                onLeadingTap: () => Navigator.maybePop(context),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
                  children: [
                    _selectorCard(),
                    const SizedBox(height: 12),
                    if (existingClose.isNotEmpty)
                      _alreadyClosedBanner(existingClose.last),
                    _summaryHeader(orders.length, totalCollected),
                    const SizedBox(height: 12),
                    _kpiGrid(
                      sales: sales,
                      tips: tips,
                      cash: cash,
                      card: card,
                      transfer: transfer,
                    ),
                    const SizedBox(height: 12),
                    _moneyBreakdown(cash, card, transfer, tips, totalCollected),
                    const SizedBox(height: 12),
                    _cashAudit(expectedCash, countedCash, difference),
                    const SizedBox(height: 12),
                    _notes(),
                    const SizedBox(height: 14),
                    _saveButton(
                      state: state,
                      orders: orders,
                      cash: cash,
                      card: card,
                      transfer: transfer,
                      tips: tips,
                      expectedCash: expectedCash,
                      countedCash: countedCash,
                      difference: difference,
                    ),
                    const SizedBox(height: 18),
                    _history(state.cashClosures),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _selectorCard() {
    return KomandaCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Periodo del corte',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text(
            'Selecciona la fecha y el turno que quieres revisar.',
            style: TextStyle(
                color: KomandaTheme.softText, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 14),
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: _pickDate,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F7FC),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: KomandaTheme.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.calendar_month_rounded,
                      color: KomandaTheme.purple),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(_date(selectedDate),
                        style: const TextStyle(fontWeight: FontWeight.w900)),
                  ),
                  const Icon(Icons.chevron_right_rounded),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: ['Mañana', 'Tarde'].map((value) {
              final selected = shift == value;
              return Expanded(
                child: Padding(
                  padding: EdgeInsets.only(right: value == 'Mañana' ? 6 : 0,
                      left: value == 'Tarde' ? 6 : 0),
                  child: InkWell(
                    onTap: () => setState(() => shift = value),
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: selected
                            ? KomandaTheme.purple.withOpacity(.10)
                            : Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: selected
                              ? KomandaTheme.purple
                              : KomandaTheme.border,
                        ),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            value == 'Mañana'
                                ? Icons.wb_sunny_outlined
                                : Icons.nights_stay_outlined,
                            color: selected
                                ? KomandaTheme.purple
                                : KomandaTheme.softText,
                          ),
                          const SizedBox(height: 4),
                          Text(value,
                              style: TextStyle(
                                fontWeight: FontWeight.w900,
                                color: selected
                                    ? KomandaTheme.purple
                                    : KomandaTheme.text,
                              )),
                          Text(
                            value == 'Mañana' ? '00:00 - 14:59' : '15:00 - 23:59',
                            style: const TextStyle(
                                fontSize: 11,
                                color: KomandaTheme.softText,
                                fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _summaryHeader(int orders, double total) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          KomandaTheme.purple.withOpacity(.10),
          KomandaTheme.blue.withOpacity(.05),
        ]),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: KomandaTheme.purple.withOpacity(.13)),
      ),
      child: Row(
        children: [
          const CircleAvatar(
            backgroundColor: Colors.white,
            child: Icon(Icons.point_of_sale_rounded, color: KomandaTheme.purple),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('$shift · ${_date(selectedDate)}',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
                Text('$orders tickets cobrados',
                    style: const TextStyle(
                        color: KomandaTheme.softText,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          Text(_money(total),
              style: const TextStyle(
                  fontSize: 20,
                  color: KomandaTheme.purple,
                  fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }

  Widget _kpiGrid({
    required double sales,
    required double tips,
    required double cash,
    required double card,
    required double transfer,
  }) {
    return LayoutBuilder(builder: (context, constraints) {
      final width = (constraints.maxWidth - 10) / 2;
      return Wrap(
        spacing: 10,
        runSpacing: 10,
        children: [
          _kpi(width, 'Ventas', sales, Icons.payments_outlined),
          _kpi(width, 'Propinas', tips, Icons.volunteer_activism_outlined),
          _kpi(width, 'Efectivo', cash, Icons.money_rounded),
          _kpi(width, 'No efectivo', card + transfer, Icons.credit_card_rounded),
        ],
      );
    });
  }

  Widget _kpi(double width, String label, double value, IconData icon) {
    return SizedBox(
      width: width,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: KomandaTheme.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: KomandaTheme.purple),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          fontSize: 12,
                          color: KomandaTheme.softText,
                          fontWeight: FontWeight.w700)),
                  Text(_money(value),
                      style: const TextStyle(fontWeight: FontWeight.w900)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _moneyBreakdown(double cash, double card, double transfer, double tips,
      double total) {
    return KomandaCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Desglose del turno',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          _row('Efectivo', cash),
          _row('Tarjeta', card),
          _row('Transferencia', transfer),
          _row('Propinas', tips),
          const Divider(height: 22),
          _row('Total cobrado', total, strong: true),
        ],
      ),
    );
  }

  Widget _cashAudit(double expected, double counted, double difference) {
    final isBalanced = difference.abs() < .01;
    final differenceColor = isBalanced
        ? KomandaTheme.green
        : difference < 0
            ? KomandaTheme.red
            : KomandaTheme.orange;

    return KomandaCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Arqueo de efectivo',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text(
            'Cuenta físicamente el efectivo en caja. El sistema compara lo contado contra lo esperado.',
            style: TextStyle(
                color: KomandaTheme.softText, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 14),
          _row('Efectivo esperado', expected, strong: true),
          const SizedBox(height: 10),
          TextField(
            controller: countedCashController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
            ],
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              labelText: 'Efectivo contado',
              prefixText: '\$ ',
              prefixIcon: Icon(Icons.calculate_rounded),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              color: differenceColor.withOpacity(.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: differenceColor.withOpacity(.25)),
            ),
            child: Row(
              children: [
                Icon(
                  isBalanced
                      ? Icons.check_circle_outline
                      : difference < 0
                          ? Icons.trending_down_rounded
                          : Icons.trending_up_rounded,
                  color: differenceColor,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    isBalanced
                        ? 'Caja cuadrada'
                        : difference < 0
                            ? 'Faltante de ${_money(difference.abs())}'
                            : 'Sobrante de ${_money(difference)}',
                    style: TextStyle(
                        color: differenceColor, fontWeight: FontWeight.w900),
                  ),
                ),
                Text(_money(difference),
                    style: TextStyle(
                        color: differenceColor, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _notes() {
    return KomandaCard(
      child: TextField(
        controller: notesController,
        minLines: 2,
        maxLines: 4,
        decoration: const InputDecoration(
          labelText: 'Observaciones del corte',
          hintText: 'Ej. retiro de efectivo, diferencia revisada, incidencia...',
          prefixIcon: Icon(Icons.notes_rounded),
          border: OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _saveButton({
    required KomandaState state,
    required List<KomandaOrder> orders,
    required double cash,
    required double card,
    required double transfer,
    required double tips,
    required double expectedCash,
    required double countedCash,
    required double difference,
  }) {
    return SizedBox(
      width: double.infinity,
      child: FilledButton.icon(
        onPressed: state.status == KomandaStatus.saving
            ? null
            : () async {
                if (countedCashController.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Captura el efectivo contado antes de cerrar.')),
                  );
                  return;
                }

                final confirmed = await showDialog<bool>(
                  context: context,
                  builder: (dialogContext) => AlertDialog(
                    title: const Text('Confirmar corte'),
                    content: Text(
                      'Se guardará el corte de $shift del ${_date(selectedDate)}.\n\n'
                      'Tickets: ${orders.length}\n'
                      'Efectivo esperado: ${_money(expectedCash)}\n'
                      'Efectivo contado: ${_money(countedCash)}\n'
                      'Diferencia: ${_money(difference)}',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(dialogContext, false),
                        child: const Text('Cancelar'),
                      ),
                      FilledButton(
                        onPressed: () => Navigator.pop(dialogContext, true),
                        child: const Text('Guardar corte'),
                      ),
                    ],
                  ),
                );

                if (confirmed != true || !mounted) return;

                context.read<KomandaBloc>().add(
                      KomandaCashCloseSaved(
                        KomandaCashClose(
                          id: DateTime.now().microsecondsSinceEpoch.toString(),
                          openedAt: shiftStart,
                          closedAt: shiftEnd,
                          cashTotal: cash,
                          cardTotal: card,
                          transferTotal: transfer,
                          tipsTotal: tips,
                          expectedTotal: expectedCash,
                          countedCash: countedCash,
                          difference: difference,
                          paidOrders: orders.length,
                          notes: notesController.text.trim(),
                        ),
                      ),
                    );
              },
        icon: state.status == KomandaStatus.saving
            ? const Text(
                'Actualizando...',
                style: TextStyle(fontWeight: FontWeight.w800),
              )
            : const Icon(Icons.lock_rounded),
        label: const Text('Cerrar y guardar corte'),
      ),
    );
  }

  Widget _history(List<KomandaCashClose> closes) {
    final sorted = [...closes]..sort((a, b) => b.openedAt.compareTo(a.openedAt));
    return KomandaCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Historial de cortes',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          if (sorted.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(
                child: Text('Aún no hay cortes guardados.',
                    style: TextStyle(color: KomandaTheme.softText)),
              ),
            )
          else
            ...sorted.take(12).map((close) {
              final turn = close.openedAt.hour < 15 ? 'Mañana' : 'Tarde';
              final color = close.difference.abs() < .01
                  ? KomandaTheme.green
                  : KomandaTheme.orange;
              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(
                  backgroundColor: color.withOpacity(.10),
                  child: Icon(Icons.receipt_long_rounded, color: color),
                ),
                title: Text('${_date(close.openedAt)} · $turn',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text(
                    '${close.paidOrders} tickets · Diferencia ${_money(close.difference)}'),
                trailing: Text(_money(close.cashTotal + close.cardTotal + close.transferTotal + close.tipsTotal),
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              );
            }),
        ],
      ),
    );
  }

  Widget _alreadyClosedBanner(KomandaCashClose close) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: KomandaTheme.orange.withOpacity(.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: KomandaTheme.orange.withOpacity(.20)),
      ),
      child: const Row(
        children: [
          Icon(Icons.info_outline_rounded, color: KomandaTheme.orange),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Ya existe un corte guardado para esta fecha y turno. Si guardas otro, quedará como un nuevo registro de auditoría.',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  List<KomandaOrder> _ordersForShift(List<KomandaOrder> all) {
    return all.where((order) {
      if (!order.isPaid || order.status == KomandaOrderStatus.cancelled) return false;
      final paidAt = order.paidAt;
      if (paidAt == null) return false;
      final local = paidAt.toLocal();
      return !local.isBefore(shiftStart) && !local.isAfter(shiftEnd);
    }).toList()
      ..sort((a, b) => (a.paidAt ?? a.createdAt).compareTo(b.paidAt ?? b.createdAt));
  }

  double _sumByMethod(List<KomandaOrder> orders, String target) {
    return orders.where((o) => _method(o.paymentMethod) == target).fold<double>(
          0,
          (sum, o) => sum + o.total + o.tipAmount,
        );
  }

  String _method(String raw) {
    final value = raw.trim().toLowerCase();
    if (value.contains('efect') || value == 'cash') return 'cash';
    if (value.contains('tarj') || value == 'card') return 'card';
    if (value.contains('transf') || value == 'transfer') return 'transfer';
    return value;
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2024),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (picked != null && mounted) {
      setState(() => selectedDate = picked);
    }
  }

  double _parseMoney(String value) =>
      double.tryParse(value.trim().replaceAll(',', '')) ?? 0;

  bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  String _money(num value) {
    final parts = value.abs().toStringAsFixed(2).split('.');
    final integer = parts[0].replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => ',');
    return '${value < 0 ? '-\$' : '\$'}$integer.${parts[1]}';
  }

  String _date(DateTime value) =>
      '${value.day.toString().padLeft(2, '0')}/${value.month.toString().padLeft(2, '0')}/${value.year}';

  Widget _row(String label, double value, {bool strong = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: TextStyle(
                    fontWeight: strong ? FontWeight.w900 : FontWeight.w700,
                    color: strong ? KomandaTheme.text : KomandaTheme.softText)),
          ),
          Text(_money(value),
              style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: strong ? 17 : 14,
                  color: strong ? KomandaTheme.purple : KomandaTheme.text)),
        ],
      ),
    );
  }
}
