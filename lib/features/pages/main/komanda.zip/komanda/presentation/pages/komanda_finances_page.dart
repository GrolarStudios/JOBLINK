import 'package:flutter/material.dart';
import '../../core/komanda_theme.dart';
import '../../data/datasources/komanda_remote_datasource.dart';
import '../widgets/komanda_widgets.dart';

class KomandaFinancesPage extends StatefulWidget {
  final KomandaRemoteDataSource remote;
  const KomandaFinancesPage({super.key, required this.remote});
  @override State<KomandaFinancesPage> createState() => _KomandaFinancesPageState();
}

class _KomandaFinancesPageState extends State<KomandaFinancesPage> {
  Map<String,dynamic> summary = const {};
  List<Map<String,dynamic>> expenses = const [];
  bool loading = true;
  int page = 0;
  static const pageSize = 50;

  @override void initState(){ super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final r=await Future.wait([widget.remote.getFinanceSummary(),widget.remote.getExpenses()]);
      if(mounted)setState((){summary=r[0] as Map<String,dynamic>; expenses=r[1] as List<Map<String,dynamic>>; loading=false; page=0;});
    } catch(e){ if(mounted)setState(()=>loading=false); }
  }

  double _n(String k)=>double.tryParse('${summary[k]??0}')??0;
  double _expenseTotal()=>expenses.fold(0,(s,e)=>s+(double.tryParse('${e['amount']??0}')??0));

  @override Widget build(BuildContext context){
    final sales=_n('salesMonth');
    final expensesMonth=_n('expensesMonth');
    final result=sales-expensesMonth;
    final pages=(expenses.length/pageSize).ceil().clamp(1,999999);
    if(page>=pages) page=pages-1;
    final visible=expenses.skip(page*pageSize).take(pageSize).toList();
    return KomandaPhoneFrame(child:Column(children:[
      const KomandaHeader(title:'Finanzas',bell:false),
      Expanded(child:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
        Wrap(spacing:10,runSpacing:10,children:[
          _metric('Ventas hoy',_n('salesToday'),Icons.payments),
          _metric('Ingresos del mes',sales,Icons.trending_up),
          _metric('Egresos del mes',expensesMonth,Icons.trending_down),
          _metric('Resultado del mes',result,Icons.account_balance_wallet),
        ]),
        const SizedBox(height:18),
        _statement('Estado de resultados',[
          _line('Ingresos / ventas',sales),
          _line('(-) Egresos operativos',-expensesMonth),
          _line('Utilidad / pérdida del periodo',result,bold:true),
        ]),
        const SizedBox(height:12),
        _statement('Balance general operativo',[
          _line('ACTIVO · Disponible generado',result),
          _line('PASIVO · Registrado',0),
          _line('CAPITAL / RESULTADO ACUMULADO',result,bold:true),
        ], note:'Vista operativa con la información disponible en Grolar POS. Al agregar cuentas por cobrar, bancos, inventario, proveedores y deudas se podrá presentar el balance contable completo.'),
        const SizedBox(height:18),
        Row(children:[const Expanded(child:Text('Egresos',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900))),FilledButton.icon(onPressed:_addExpense,icon:const Icon(Icons.add),label:const Text('Registrar egreso'))]),
        const SizedBox(height:8),
        if(expenses.isEmpty)const KomandaCard(child:Text('No hay egresos registrados.')),
        ...visible.map((e)=>KomandaCard(child:ListTile(contentPadding:EdgeInsets.zero,leading:const CircleAvatar(child:Icon(Icons.receipt_long_outlined)),title:Text('${e['concept']??'Egreso'}',style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${e['expense_date']??''}${('${e['notes']??''}').trim().isEmpty?'':' · ${e['notes']}'}'),trailing:Text('-\$${e['amount']??0}',style:const TextStyle(fontWeight:FontWeight.w900,color:KomandaTheme.red))))),
        if(expenses.length>pageSize) _pager(page,pages),
      ])))
    ]));
  }

  Widget _metric(String t,double v,IconData i)=>SizedBox(width:170,child:KomandaCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(i,color:KomandaTheme.purple),const SizedBox(height:8),Text(t,style:const TextStyle(color:KomandaTheme.softText,fontWeight:FontWeight.w700)),Text('\$${v.toStringAsFixed(2)}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900))])));
  Widget _line(String label,double value,{bool bold=false})=>Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Row(children:[Expanded(child:Text(label,style:TextStyle(fontWeight:bold?FontWeight.w900:FontWeight.w600))),Text('${value<0?'-':''}\$${value.abs().toStringAsFixed(2)}',style:TextStyle(fontWeight:bold?FontWeight.w900:FontWeight.w700))]));
  Widget _statement(String title,List<Widget> rows,{String? note})=>KomandaCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const Divider(height:22),...rows,if(note!=null)...[const Divider(),Text(note,style:const TextStyle(fontSize:12,color:KomandaTheme.softText))]]));
  Widget _pager(int current,int total)=>Padding(padding:const EdgeInsets.only(top:8),child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[IconButton(onPressed:current>0?()=>setState(()=>page--):null,icon:const Icon(Icons.chevron_left)),Text('Página ${current+1} de $total · 50 por página',style:const TextStyle(fontWeight:FontWeight.w800)),IconButton(onPressed:current+1<total?()=>setState(()=>page++):null,icon:const Icon(Icons.chevron_right))]));

  Future<void> _addExpense() async {
    final concept = TextEditingController();
    final amount = TextEditingController();
    final notes = TextEditingController();
    final formKey = GlobalKey<FormState>();
    String category = 'Insumos y materia prima';
    bool saving = false;
    final categories = <String>[
      'Insumos y materia prima',
      'Nómina',
      'Renta y servicios',
      'Transporte y entregas',
      'Mantenimiento',
      'Publicidad',
      'Impuestos',
      'Otros gastos',
    ];
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, update) => AlertDialog(
            title: const Text('Agregar egreso'),
            content: SizedBox(
              width: 440,
              child: SingleChildScrollView(
                child: Form(
                  key: formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Registra un gasto del negocio. Se descontará de los resultados del mes.'),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: category,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: '¿En qué gastaste?',
                          border: OutlineInputBorder(),
                        ),
                        items: categories.map((item) => DropdownMenuItem(
                          value: item, child: Text(item),
                        )).toList(),
                        onChanged: saving ? null : (value) => update(() => category = value ?? category),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: concept,
                        enabled: !saving,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: const InputDecoration(
                          labelText: 'Descripción del gasto',
                          hintText: 'Ej. Compra de tortillas',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) => (value ?? '').trim().isEmpty
                            ? 'Escribe qué compraste o pagaste' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: amount,
                        enabled: !saving,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(
                          labelText: '¿Cuánto pagaste?',
                          prefixText: r'$ ',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          final number = double.tryParse((value ?? '').trim().replaceAll(',', '.'));
                          return number == null || !number.isFinite || number <= 0
                              ? 'Ingresa un importe mayor a cero' : null;
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: notes,
                        enabled: !saving,
                        maxLines: 2,
                        decoration: const InputDecoration(
                          labelText: 'Notas (opcional)',
                          hintText: 'Ej. Factura o proveedor',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: saving ? null : () => Navigator.pop(dialogContext),
                child: const Text('Cancelar'),
              ),
              FilledButton.icon(
                onPressed: saving ? null : () async {
                  if (!(formKey.currentState?.validate() ?? false)) return;
                  update(() => saving = true);
                  try {
                    await widget.remote.createExpense({
                      'concept': concept.text.trim(),
                      'amount': double.parse(amount.text.trim().replaceAll(',', '.')),
                      'notes': '$category${notes.text.trim().isEmpty ? '' : ' · ${notes.text.trim()}'}',
                    });
                    if (!dialogContext.mounted) return;
                    Navigator.pop(dialogContext);
                    await _load();
                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Egreso registrado correctamente.')),
                    );
                  } catch (error) {
                    if (dialogContext.mounted) {
                      update(() => saving = false);
                      ScaffoldMessenger.of(dialogContext).showSnackBar(
                        SnackBar(content: Text('No se pudo guardar el egreso: $error')),
                      );
                    }
                  }
                },
                icon: saving
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.save_outlined),
                label: Text(saving ? 'Guardando...' : 'Guardar egreso'),
              ),
            ],
          ),
        ),
      );
    } finally {
      // Los campos pertenecen al diálogo y se liberan después de cerrarlo.
      concept.dispose();
      amount.dispose();
      notes.dispose();
    }
  }
}
