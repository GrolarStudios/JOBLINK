import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/komanda_theme.dart';
import '../../domain/entities/komanda_order.dart';
import '../bloc/komanda_bloc.dart';
import '../bloc/komanda_event.dart';
import '../bloc/komanda_state.dart';
import '../widgets/komanda_widgets.dart';
import 'komanda_tables_admin_page.dart';

class KomandaTablesOverviewPage extends StatefulWidget {
  const KomandaTablesOverviewPage({super.key});

  @override
  State<KomandaTablesOverviewPage> createState() => _KomandaTablesOverviewPageState();
}

class _KomandaTablesOverviewPageState extends State<KomandaTablesOverviewPage> {
  String _search = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<KomandaBloc>().add(const KomandaRefreshed());
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<KomandaBloc, KomandaState>(
      builder: (context, state) {
        final query = _search.trim().toLowerCase();
        final tables = state.tables.where((t) {
          if (!t.active) return false;
          final order = state.openOrderForTable(t.name);
          return query.isEmpty ||
              t.name.toLowerCase().contains(query) ||
              (order?.shortFolio.toLowerCase().contains(query) ?? false) ||
              (order?.waiterName.toLowerCase().contains(query) ?? false) ||
              (order?.status.label.toLowerCase().contains(query) ?? false);
        }).toList();

        return KomandaPhoneFrame(
          child: Column(
            children: [
              KomandaHeader(
                title: 'Mesas',
                subtitle: 'Vista general',
                onLeadingTap: () => Navigator.maybePop(context),
              ),
              KomandaSearchField(
                hintText: 'Buscar folio o nombre',
                onChanged: (value) => setState(() => _search = value),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const KomandaTablesAdminPage()),
                      );
                      if (context.mounted) context.read<KomandaBloc>().add(const KomandaRefreshed());
                    },
                    icon: const Icon(Icons.add_business_rounded),
                    label: const Text('Administrar mesas'),
                  ),
                ),
              ),
              Expanded(
                child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: KomandaTheme.purple.withOpacity(.08),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: KomandaTheme.purple.withOpacity(.18)),
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.visibility_outlined, color: KomandaTheme.purple),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Esta pantalla es solo informativa. Para levantar un pedido usa “Nuevo pedido”.',
                                style: TextStyle(color: KomandaTheme.text, fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      if (tables.isEmpty)
                        const KomandaCard(child: Text('No hay mesas que coincidan con la búsqueda.'))
                      else
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: tables.length,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: 1.05,
                          ),
                          itemBuilder: (context, index) {
                            final table = tables[index].name;
                            return _TableVisualCard(table: table, order: state.openOrderForTable(table));
                          },
                        ),
                    ],
                  ),
              ),
              const BottomNavMock(index: 1),
            ],
          ),
        );
      },
    );
  }
}

class _TableVisualCard extends StatelessWidget {
  final String table;
  final KomandaOrder? order;
  const _TableVisualCard({required this.table, required this.order});

  @override
  Widget build(BuildContext context) {
    final occupied = order != null;
    final color = occupied ? KomandaTheme.orange : KomandaTheme.green;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(.35), width: 1.3),
        boxShadow: const [BoxShadow(color: Color(0x0D000000), blurRadius: 12, offset: Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
              child: Icon(Icons.table_restaurant_outlined, color: color),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(20)),
              child: Text(occupied ? 'Ocupada' : 'Disponible', style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w900)),
            ),
          ]),
          const SizedBox(height: 12),
          Text(table, style: const TextStyle(color: KomandaTheme.text, fontSize: 17, fontWeight: FontWeight.w900)),
          const Spacer(),
          if (order == null)
            const Text('Sin pedido activo', style: TextStyle(color: KomandaTheme.softText, fontSize: 12, fontWeight: FontWeight.w700))
          else ...[
            Text('#${order!.shortFolio} · ${order!.status.label}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: KomandaTheme.text, fontSize: 11, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(order!.waiterName.isEmpty ? 'Sin mesero asignado' : order!.waiterName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: KomandaTheme.softText, fontSize: 11, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
    );
  }
}
