import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../../core/routes/route_names.dart';
import '../../core/komanda_theme.dart';
import '../../domain/entities/komanda_entities.dart' as ui;
import '../../domain/entities/komanda_product.dart';
import '../../domain/entities/komanda_order.dart';
import '../../domain/entities/komanda_waiter.dart';
import 'komanda_detail_page.dart';
import 'komanda_tables_overview_page.dart';
import '../bloc/komanda_bloc.dart';
import '../bloc/komanda_event.dart';
import '../bloc/komanda_state.dart';
import '../widgets/komanda_widgets.dart';
import '../shared/widgets/komanda_item_detail_view.dart';
import '../shared/widgets/komanda_order_sections_view.dart';

class KomandaOrderFlowPage extends StatefulWidget {
  const KomandaOrderFlowPage({super.key});
  @override State<KomandaOrderFlowPage> createState() => _KomandaOrderFlowPageState();
}

class _KomandaOrderFlowPageState extends State<KomandaOrderFlowPage> {
  int step = 0;
  String _selectedTable = '';
  String _selectedWaiterId = '';
  String search = '';
  String category = 'Seleccionados';
  final customerNameController = TextEditingController();
  final customerPhoneController = TextEditingController();
  final deliveryAddressController = TextEditingController();
  final generalNotesController = TextEditingController();
  KomandaOrderType? orderType;
  bool isUrgent = false;
  int plateNumber = 1;
  double deliveryFee = 5;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<KomandaBloc>().add(const KomandaRefreshed(showLoading: false));
    });
  }

  @override
  void dispose() {
    customerNameController.dispose();
    customerPhoneController.dispose();
    deliveryAddressController.dispose();
    generalNotesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<KomandaBloc, KomandaState>(
      listenWhen: (p, c) => p.status != c.status,
      listener: (context, state) {
        if (state.status == KomandaStatus.ready &&
            step == 3 &&
            state.cart.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Pedido guardado correctamente.'),
              behavior: SnackBarBehavior.floating,
            ),
          );

          Navigator.pushNamedAndRemoveUntil(
            context,
            RouteNames.komandaDashboard,
            (route) => false,
          );
          return;
        }

        if (state.status == KomandaStatus.failure &&
            state.errorMessage != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'No se pudo guardar el pedido. ${state.errorMessage}',
              ),
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      },
      builder: (context, state) => KomandaPhoneFrame(
        child: Column(children: [
          KomandaHeader(title: 'Nuevo pedido', subtitle: 'Paso ${step + 1} de 4'),
          _Progress(current: step),
          Expanded(child: SingleChildScrollView(padding: const EdgeInsets.only(bottom: 16), child: _body(context, state))),
        ]),
      ),
    );
  }

  Widget _body(BuildContext context, KomandaState state) {
    switch (step) {
      case 0: return _tableStep(context, state);
      case 1: return _productsStep(context, state);
      case 2: return _summaryStep(context, state);
      default: return _confirmationStep(context, state);
    }
  }

  Widget _tableStep(BuildContext context, KomandaState state) {
    final isDelivery = orderType == KomandaOrderType.delivery;
    final canContinue = orderType != null;

    return Column(children: [
      KomandaCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '¿Cómo será el pedido?',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: KomandaTheme.text),
            ),
            const SizedBox(height: 6),
            const Text(
              'Todos los pedidos se identifican por ficha y pueden separarse por platos para cocina.',
              style: TextStyle(color: KomandaTheme.softText, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _OrderTypeCard(
                selected: orderType == KomandaOrderType.dineIn,
                icon: Icons.restaurant_outlined,
                title: 'Para aquí',
                onTap: () => setState(() => orderType = KomandaOrderType.dineIn),
              )),
              const SizedBox(width: 8),
              Expanded(child: _OrderTypeCard(
                selected: orderType == KomandaOrderType.takeaway,
                icon: Icons.takeout_dining_outlined,
                title: 'Para llevar',
                onTap: () => setState(() => orderType = KomandaOrderType.takeaway),
              )),
              const SizedBox(width: 8),
              Expanded(child: _OrderTypeCard(
                selected: orderType == KomandaOrderType.delivery,
                icon: Icons.delivery_dining_outlined,
                title: 'Domicilio',
                onTap: () => setState(() => orderType = KomandaOrderType.delivery),
              )),
            ]),
          ],
        ),
      ),
      if (isDelivery)
        KomandaCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: KomandaTheme.purple.withOpacity(.06),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Row(children: [
                  Icon(Icons.local_shipping_outlined, color: KomandaTheme.purple),
                  SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Datos de domicilio', style: TextStyle(fontWeight: FontWeight.w900)),
                    Text('Son opcionales, pero se guardan con el pedido si los capturas.', style: TextStyle(fontSize: 11, color: KomandaTheme.softText, fontWeight: FontWeight.w700)),
                  ])),
                ]),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: customerNameController,
                textCapitalization: TextCapitalization.words,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'Nombre del cliente (opcional)',
                  prefixIcon: Icon(Icons.person_outline),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: customerPhoneController,
                keyboardType: TextInputType.phone,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'Teléfono (opcional)',
                  prefixIcon: Icon(Icons.phone_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: deliveryAddressController,
                textCapitalization: TextCapitalization.sentences,
                minLines: 2,
                maxLines: 3,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'Domicilio / dirección (opcional)',
                  prefixIcon: Icon(Icons.location_on_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 14),
              const Text('Costo de envío', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [5.0, 10.0, 15.0, 20.0].map((value) => ChoiceChip(
                  label: Text('\$${value.toStringAsFixed(0)}'),
                  selected: deliveryFee == value,
                  onSelected: (_) => setState(() => deliveryFee = value),
                )).toList(),
              ),
            ],
          ),
        ),
      _navigation(
        onBack: () => Navigator.maybePop(context),
        onNext: canContinue ? () => setState(() { search = ''; category = 'Seleccionados'; step = 1; }) : null,
      ),
    ]);
  }

  Widget _productsStep(BuildContext context, KomandaState state) {
    final categories = ['Seleccionados', ...{...state.products.map((p) => p.category)}];
    final selectedProductIds = state.cart.values.map((item) => item.productId).toSet();
    final products = state.products.where((p) {
      final byCategory = category == 'Seleccionados'
          ? selectedProductIds.contains(p.id)
          : p.category == category;
      final bySearch = search.isEmpty ||
          p.name.toLowerCase().contains(search.toLowerCase()) ||
          p.category.toLowerCase().contains(search.toLowerCase());
      return p.available && byCategory && bySearch;
    }).toList();
    return Column(children: [
      KomandaSearchField(
        hintText: 'Buscar producto...',
        onChanged: (value) => setState(() => search = value),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
        child: Wrap(
          spacing: 8,
          runSpacing: 8,
          children: categories
              .map((value) => _LargeCategoryFilter(
                    text: value,
                    selected: category == value,
                    onTap: () => setState(() => category = value),
                  ))
              .toList(),
        ),
      ),
      if (orderType != null)
        KomandaCard(
          child: Row(
            children: [
              const CircleAvatar(
                backgroundColor: Color(0xFFF1EAFF),
                child: Icon(Icons.dining_outlined, color: KomandaTheme.purple),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Plato actual', style: TextStyle(fontWeight: FontWeight.w900)),
                    Text(
                      'Todo lo que agregues quedará separado en este plato para cocina.',
                      style: TextStyle(fontSize: 11, color: KomandaTheme.softText, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: plateNumber <= 1 ? null : () => setState(() => plateNumber--),
                icon: const Icon(Icons.remove_circle_outline),
              ),
              Text('Plato $plateNumber', style: const TextStyle(fontWeight: FontWeight.w900)),
              IconButton(
                onPressed: () => setState(() => plateNumber++),
                icon: const Icon(Icons.add_circle_outline),
              ),
            ],
          ),
        ),
      KomandaCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(category == 'Seleccionados' ? 'Productos' : category, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: KomandaTheme.text)),
          KChip(text: '${state.cart.values.fold<int>(0, (s, i) => s + i.quantity)} en carrito', icon: Icons.shopping_cart_outlined),
        ]),
        if (products.isEmpty) Padding(padding: const EdgeInsets.all(28), child: Center(child: Text(category == 'Seleccionados' ? 'Aún no has agregado productos. Toca una categoría para ver el catálogo.' : 'No se encontraron productos en esta categoría.', textAlign: TextAlign.center)))
        else ...products.map((p) {
          final productEntries = state.cart.entries
              .where((entry) => entry.value.productId == p.id)
              .toList();
          final qty = productEntries.fold<int>(
            0,
            (sum, entry) => sum + entry.value.quantity,
          );
          final lastCartKey = productEntries.isEmpty ? null : productEntries.last.key;
          final view = ui.KomandaProduct(name: p.printName, note: p.category, quantity: qty, price: p.price, image: '');
          return Column(children: [
            ProductTile(
              product: view, image: true, controls: true,
              onAdd: () => _addConfiguredProduct(context, state, p),
              onRemove: lastCartKey == null
                  ? null
                  : () => context.read<KomandaBloc>().add(
                        KomandaProductRemoved(lastCartKey),
                      ),
            ),
            const Divider(height: 1),
          ]);
        }),
        if (state.cart.isNotEmpty) ...[
          const SizedBox(height: 14),
          const Text('Detalle seleccionado', style: TextStyle(fontWeight: FontWeight.w900, color: KomandaTheme.purple)),
          const SizedBox(height: 8),
          ..._cartEntriesByPlate(state.cart).expand((group) => [
                Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 6),
                  child: Text(
                    group.$1,
                    style: const TextStyle(fontWeight: FontWeight.w900, color: KomandaTheme.purple, fontSize: 15),
                  ),
                ),
                ...group.$2.map((entry) => _SelectedCartItemCard(
                      cartKey: entry.key,
                      item: entry.value,
                      onRemove: () => context.read<KomandaBloc>().add(
                            KomandaProductRemoved(entry.key),
                          ),
                    )),
              ]),
        ],
      ])),
    _totals(state.cartTotal),
      _navigation(onBack: () => setState(() => step = 0), onNext: state.cart.isNotEmpty ? () => setState(() => step = 2) : null),
    ]);
  }

  Widget _summaryStep(BuildContext context, KomandaState state) => Column(children: [
    KomandaCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Resumen del pedido', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: KomandaTheme.text)),
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          'Ficha #${_nextFicha(state)}',
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: KomandaTheme.purple),
        ),
      ),
      const Divider(),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Productos (${state.cart.length})', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), InkWell(onTap: () => setState(() => step = 1), child: const Text('✎ Editar', style: TextStyle(color: KomandaTheme.purple, fontWeight: FontWeight.w900)))]),
      KomandaOrderSectionsView(
        items: state.cart.values.toList(),
        showPrice: true,
      ),
    ])),
    _totals(state.cartTotal),
    if (orderType == KomandaOrderType.takeaway || orderType == KomandaOrderType.delivery)
      KomandaCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Indicaciones para llevar',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: KomandaTheme.text),
            ),
            const SizedBox(height: 4),
            const Text(
              'Escribe aquí qué salsas, ingredientes o cosas quieren que se manden aparte. Esta nota es del pedido completo.',
              style: TextStyle(color: KomandaTheme.softText, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: generalNotesController,
              minLines: 2,
              maxLines: 4,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Nota general para llevar',
                hintText: 'Ej. mandar salsa verde aparte, cebolla, limones...',
                prefixIcon: Icon(Icons.takeout_dining_outlined),
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ),
    KomandaCard(child: SwitchListTile.adaptive(contentPadding: EdgeInsets.zero, value: isUrgent, onChanged: (value) => setState(() => isUrgent = value), secondary: Icon(Icons.priority_high_rounded, color: isUrgent ? KomandaTheme.red : KomandaTheme.softText), title: const Text('¿Es un pedido urgente?', style: TextStyle(fontWeight: FontWeight.w900)), subtitle: Text(isUrgent ? 'Se marcará como prioritario para cocina.' : 'Se atenderá con prioridad normal.'))),
    _navigation(onBack: () => setState(() => step = 1), onNext: () => setState(() => step = 3)),
  ]);

  Widget _confirmationStep(BuildContext context, KomandaState state) => Column(children: [
    Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Row(children: [
        const Expanded(child: Text('Mesa y mesero', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
        IconButton(tooltip: 'Actualizar disponibilidad', onPressed: () => context.read<KomandaBloc>().add(const KomandaRefreshed(showLoading: false)), icon: const Icon(Icons.refresh_rounded)),
        IconButton(tooltip: 'Ver todas las mesas', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const KomandaTablesOverviewPage())), icon: const Icon(Icons.table_restaurant_outlined)),
      ]),
    ),
      if (orderType == KomandaOrderType.dineIn)
      KomandaCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Mesa disponible', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: state.tables.where((table) => table.active).map((table) {
          final occupied = state.openOrderForTable(table.name) != null;
          return ChoiceChip(
            label: Text('${table.name} · ${occupied ? 'Ocupada' : 'Disponible'}'),
            selected: _selectedTable == table.name,
            onSelected: occupied ? null : (_) {
              setState(() => _selectedTable = table.name);
              context.read<KomandaBloc>().add(KomandaTableSelected(table.name));
            },
          );
        }).toList()),
        if (state.tables.where((table) => table.active && state.openOrderForTable(table.name) == null).isEmpty)
          const Padding(padding: EdgeInsets.only(top: 8), child: Text('No hay mesas disponibles.')),
      ])),
    KomandaCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Mesero', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: state.activeWaiters.map((waiter) => ChoiceChip(
          avatar: const Icon(Icons.person_outline_rounded, size: 18),
          label: Text(waiter.name),
          selected: _selectedWaiterId == waiter.id,
          onSelected: (_) => setState(() => _selectedWaiterId = waiter.id),
        )).toList(),
      ),
      if (state.activeWaiters.isEmpty)
        const Padding(padding: EdgeInsets.only(top: 8), child: Text('No hay meseros activos configurados.')),
    ])),
    KomandaCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Confirmación pedido', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: KomandaTheme.text)),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(
          child: Text(
            'Ficha #${_nextFicha(state)}',
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: KomandaTheme.purple),
          ),
        ),
        IconButton(
          tooltip: 'Cambiar tipo de pedido',
          onPressed: () => setState(() => step = 0),
          icon: const Icon(Icons.edit_outlined),
        ),
      ]),
    ])),
    KomandaCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Productos (${state.cart.length})', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
      KomandaOrderSectionsView(
        items: state.cart.values.toList(),
        showPrice: true,
      ),
    ])),
    if (orderType == KomandaOrderType.delivery)
      KomandaCard(
        child: ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const CircleAvatar(
            backgroundColor: Color(0xFFF1EAFF),
            child: Icon(Icons.home_outlined, color: KomandaTheme.purple),
          ),
          title: const Text('Domicilio', style: TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text(
            deliveryAddressController.text.trim().isEmpty
                ? 'Sin domicilio capturado'
                : deliveryAddressController.text.trim(),
            style: const TextStyle(fontWeight: FontWeight.w900, color: KomandaTheme.text),
          ),
        ),
      ),
    _totals(state.cartTotal),
    if (isUrgent) KomandaCard(child: const ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(backgroundColor: Color(0xFFFFE7E7), child: Icon(Icons.priority_high_rounded, color: KomandaTheme.red)), title: Text('Pedido urgente', style: TextStyle(fontWeight: FontWeight.w900, color: KomandaTheme.red)), subtitle: Text('Este pedido se marcará como prioritario para cocina.'))),
    Padding(
      padding: const EdgeInsets.all(18),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 390;
          final backButton = OutlinedButton(
            onPressed: () => setState(() => step = 2),
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
            child: const Text('Atrás'),
          );
          final confirmButton = FilledButton.icon(
            onPressed: state.status == KomandaStatus.saving ||
                (orderType == KomandaOrderType.dineIn &&
                 (_selectedTable.isEmpty ||
                  !state.tables.any((t) => t.active && t.name == _selectedTable && state.openOrderForTable(t.name) == null)))
                ? null : () => context.read<KomandaBloc>().add(KomandaOrderCreated(
              notes: (orderType == KomandaOrderType.takeaway || orderType == KomandaOrderType.delivery)
                  ? generalNotesController.text.trim()
                  : '',
              orderType: orderType ?? KomandaOrderType.dineIn,
              customerName: customerNameController.text.trim(),
              customerPhone: customerPhoneController.text.trim(),
              deliveryAddress: deliveryAddressController.text.trim(),
              deliveryFee: orderType == KomandaOrderType.delivery ? deliveryFee : 0,
              isUrgent: isUrgent,
              waiter: state.activeWaiters.where((w) => w.id == _selectedWaiterId).isEmpty
                  ? null
                  : state.activeWaiters.firstWhere((w) => w.id == _selectedWaiterId),
            )),
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: state.status == KomandaStatus.saving
                ? const Text('Actualizando...', style: TextStyle(fontWeight: FontWeight.w800))
                : const Icon(Icons.check_circle_outline),
            label: Text(
              state.status == KomandaStatus.saving ? 'Confirmando...' : 'Confirmar pedido',
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.fade,
              softWrap: false,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
          );
          if (compact) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [confirmButton, const SizedBox(height: 10), backButton],
            );
          }
          return Row(
            children: [
              Expanded(child: backButton),
              const SizedBox(width: 12),
              Expanded(flex: 2, child: confirmButton),
            ],
          );
        },
      ),
    ),
  ]);


  Future<void> _addConfiguredProduct(
    BuildContext context,
    KomandaState state,
    KomandaProduct product,
  ) async {
    final specifications = <String>[];
    var productForCart = product;

    if (orderType != null) {
      specifications.add('Plato $plateNumber');
    }

    if (product.isPackage) {
      final packageSelections = await showModalBottomSheet<List<_PackageSelectionItem>>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (_) => _PackageCompositionSheet(
          product: product,
          allProducts: state.products,
        ),
      );
      if (!context.mounted || packageSelections == null) return;

      for (final packageItem in packageSelections) {
        final childProduct = _findProductForPackageSelection(
          state.products,
          packageItem,
        );
        if (childProduct == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'No se pudo cargar ${packageItem.productName} para configurar el paquete.',
              ),
            ),
          );
          return;
        }

        specifications.add('${packageItem.slotLabel}: ${childProduct.printName}');

        if (childProduct.hasOptions) {
          final childSpecs = await showModalBottomSheet<List<String>>(
            context: context,
            isScrollControlled: true,
            isDismissible: false,
            enableDrag: false,
            backgroundColor: Colors.transparent,
            builder: (_) => _ProductOptionsSheet(
              product: childProduct,
              availableProducts: state.products,
              initialSpecifications: const [],
              titleOverride: '${packageItem.slotLabel} · ${childProduct.printName}',
              subtitleOverride: 'Configura este producto del paquete. Esta selección es independiente de los demás productos.',
            ),
          );
          if (!context.mounted || childSpecs == null) return;
          for (final childSpec in childSpecs) {
            specifications.add('${packageItem.slotLabel} · $childSpec');
          }
        }
      }
    }

    if (!product.isPackage && _isMeatByWeight(product)) {
      final selection = await _selectMeatAmount(
        context,
        pricePerKg: product.price,
      );
      if (!context.mounted || selection == null) return;
      specifications.add('Peso: ${_formatKilograms(selection.kilograms)} kg');
      if (!_isChicharron(product)) {
        specifications.add('Importe carne: \$${selection.amount.toStringAsFixed(2)}');
      }
      productForCart = product.copyWith(price: selection.amount);
    }

    if (!product.isPackage && product.hasOptions) {
      final result = await showModalBottomSheet<List<String>>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) => _ProductOptionsSheet(
          product: product,
          availableProducts: state.products,
          initialSpecifications: const [],
          subtitleOverride: 'Selecciona las opciones configuradas para este producto.',
        ),
      );
      if (!context.mounted || result == null) return;
      specifications.addAll(result);
      productForCart = productForCart.copyWith(
        price: productForCart.price + _selectedExtrasPrice(product, result),
      );
    }

    final addConfig = await _showAddConfiguration(
      context,
      productName: product.name,
      specifications: specifications,
    );
    if (!context.mounted || addConfig == null) return;

    final finalSpecifications = [...specifications];
    if (addConfig.note.trim().isNotEmpty) {
      finalSpecifications.add('Nota: ${addConfig.note.trim()}');
    }

    context.read<KomandaBloc>().add(
          KomandaConfiguredProductAdded(
            product: productForCart,
            specifications: finalSpecifications,
            quantity: addConfig.quantity,
            separateLine: _isMeatByWeight(product),
          ),
        );
  }

  KomandaProduct? _findProductForPackageSelection(
    List<KomandaProduct> products,
    _PackageSelectionItem selection,
  ) {
    final id = selection.productId.trim();
    if (id.isNotEmpty) {
      for (final product in products) {
        if (product.id == id) return product;
      }
    }

    final name = selection.productName.trim().toLowerCase();
    for (final product in products) {
      if (product.name.trim().toLowerCase() == name ||
          product.printName.trim().toLowerCase() == name) {
        return product;
      }
    }
    return null;
  }

  Future<_MeatAmountSelection?> _selectMeatAmount(
    BuildContext context, {
    required double pricePerKg,
  }) {
    final controller = TextEditingController();
    var mode = _MeatAmountMode.kilograms;

    return showModalBottomSheet<_MeatAmountSelection>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheetState) {
          final raw = controller.text.trim().replaceAll(',', '.');
          final value = double.tryParse(raw) ?? 0.0;
          final kilograms = mode == _MeatAmountMode.kilograms
              ? value
              : (pricePerKg > 0 ? value / pricePerKg : 0.0);
          final amount = mode == _MeatAmountMode.money
              ? value
              : value * pricePerKg;
          final isValid = value > 0 && pricePerKg > 0;

          return Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(sheetContext).viewInsets.bottom,
            ),
            child: SafeArea(
              child: Container(
                margin: const EdgeInsets.all(12),
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Cantidad de carne',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: KomandaTheme.text),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Precio por kilo: \$${pricePerKg.toStringAsFixed(2)}',
                      style: const TextStyle(color: KomandaTheme.softText, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 14),
                    SegmentedButton<_MeatAmountMode>(
                      segments: const [
                        ButtonSegment(value: _MeatAmountMode.kilograms, icon: Icon(Icons.scale_outlined), label: Text('Kilogramos')),
                        ButtonSegment(value: _MeatAmountMode.money, icon: Icon(Icons.attach_money_rounded), label: Text('Cantidad en \$')),
                      ],
                      selected: {mode},
                      onSelectionChanged: (values) {
                        setSheetState(() {
                          mode = values.first;
                          controller.clear();
                        });
                      },
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: controller,
                      autofocus: true,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      onChanged: (_) => setSheetState(() {}),
                      decoration: InputDecoration(
                        labelText: mode == _MeatAmountMode.kilograms ? 'Kilogramos' : 'Cantidad de dinero',
                        hintText: mode == _MeatAmountMode.kilograms ? 'Ej. 0.350, 0.750, 1.250' : 'Ej. 50, 100, 250',
                        prefixIcon: Icon(mode == _MeatAmountMode.kilograms ? Icons.scale_outlined : Icons.attach_money_rounded),
                        border: const OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8F7FC),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: KomandaTheme.border),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Conversión', style: TextStyle(color: KomandaTheme.softText, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text(
                            isValid
                                ? '${_formatKilograms(kilograms)} kg = \$${amount.toStringAsFixed(2)}'
                                : 'Ingresa una cantidad mayor a 0',
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: KomandaTheme.purple),
                          ),
                          if (isValid) ...[
                            const SizedBox(height: 4),
                            Text(
                              mode == _MeatAmountMode.kilograms
                                  ? '${_formatKilograms(kilograms)} kg × \$${pricePerKg.toStringAsFixed(2)} por kg'
                                  : '\$${amount.toStringAsFixed(2)} ÷ \$${pricePerKg.toStringAsFixed(2)} por kg',
                              style: const TextStyle(color: KomandaTheme.softText, fontWeight: FontWeight.w700),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: isValid
                            ? () => Navigator.pop(sheetContext, _MeatAmountSelection(kilograms: kilograms, amount: amount))
                            : null,
                        icon: const Icon(Icons.check_circle_outline),
                        label: const Text('Usar esta cantidad'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    ).whenComplete(controller.dispose);
  }


  bool _isChicharron(KomandaProduct product) {
    final category = product.category.trim().toLowerCase();
    final name = product.name.trim().toLowerCase();
    return category.contains('chicharr') || name.contains('chicharr');
  }

  bool _isMeatByWeight(KomandaProduct product) {
    final category = product.category.trim().toLowerCase();
    final name = product.name.trim().toLowerCase();
    return category == 'carnes por kilo' ||
        (category.contains('carne') && category.contains('kilo')) ||
        name.contains('kilo');
  }

  String _formatKilograms(double value) {
    var formatted = value.toStringAsFixed(3);

    while (formatted.contains('.') && formatted.endsWith('0')) {
      formatted = formatted.substring(0, formatted.length - 1);
    }

    if (formatted.endsWith('.')) {
      formatted = formatted.substring(0, formatted.length - 1);
    }

    return formatted;
  }

  Future<_AddProductConfiguration?> _showAddConfiguration(
    BuildContext context, {
    required String productName,
    required List<String> specifications,
  }) {
    final noteController = TextEditingController();
    var quantity = 1;
    return showModalBottomSheet<_AddProductConfiguration>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: SafeArea(
            child: Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(productName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  const Text(
                    'Antes de agregar: indica cuántas veces quieres esta misma configuración y agrega una nota solo para este producto.',
                    style: TextStyle(color: KomandaTheme.softText, fontWeight: FontWeight.w700),
                  ),
                  if (specifications.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: specifications.map((value) => Chip(label: Text(value))).toList(),
                    ),
                  ],
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      const Expanded(child: Text('Repetir esta configuración', style: TextStyle(fontWeight: FontWeight.w900))),
                      IconButton(
                        onPressed: quantity <= 1 ? null : () => setSheetState(() => quantity--),
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      Container(
                        constraints: const BoxConstraints(minWidth: 42),
                        alignment: Alignment.center,
                        child: Text('$quantity', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                      ),
                      IconButton(
                        onPressed: () => setSheetState(() => quantity++),
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: noteController,
                    maxLines: 2,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: const InputDecoration(
                      labelText: 'Nota de este producto',
                      hintText: 'Ej. sin cebolla, bien dorado...',
                      prefixIcon: Icon(Icons.sticky_note_2_outlined),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => Navigator.pop(
                        context,
                        _AddProductConfiguration(quantity: quantity, note: noteController.text),
                      ),
                      icon: const Icon(Icons.add_shopping_cart_rounded),
                      label: Text(quantity == 1 ? 'Agregar al carrito' : 'Agregar $quantity iguales'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<(String, List<MapEntry<String, KomandaOrderItem>>)> _cartEntriesByPlate(
    Map<String, KomandaOrderItem> cart,
  ) {
    final groups = <String, List<MapEntry<String, KomandaOrderItem>>>{};
    for (final entry in cart.entries) {
      final label = _plateLabel(entry.value);
      groups.putIfAbsent(label, () => []).add(entry);
    }
    final values = groups.entries.toList();
    values.sort((a, b) => _plateNumber(a.key).compareTo(_plateNumber(b.key)));
    return values.map((e) => (e.key, e.value)).toList();
  }

  List<Widget> _summaryItemsByPlate(Map<String, KomandaOrderItem> cart) {
    return _cartEntriesByPlate(cart).expand((group) => <Widget>[
      Padding(
        padding: const EdgeInsets.only(top: 10, bottom: 4),
        child: Text(group.$1, style: const TextStyle(fontWeight: FontWeight.w900, color: KomandaTheme.purple)),
      ),
      ...group.$2.map((entry) => KomandaItemDetailView(item: entry.value, showPrice: true)),
    ]).toList();
  }

  String _plateLabel(KomandaOrderItem item) {
    for (final specification in item.specifications) {
      final value = specification.trim();
      if (value.toLowerCase().startsWith('plato ')) return value;
    }
    return 'Sin plato';
  }

  int _plateNumber(String label) {
    final match = RegExp(r'(\d+)').firstMatch(label);
    return int.tryParse(match?.group(1) ?? '') ?? 9999;
  }

  double _selectedExtrasPrice(KomandaProduct product, List<String> specifications) {
    var total = 0.0;
    for (final specification in specifications) {
      final separator = specification.indexOf(':');
      if (separator <= 0) continue;
      final groupName = specification.substring(0, separator).trim();
      final label = specification.substring(separator + 1).trim();
      for (final group in product.selectableOptionGroups) {
        if (group.name.trim() != groupName) continue;
        for (final option in group.optionDetails) {
          if (option.label.trim() == label) total += option.extraPrice;
        }
      }
    }
    return total;
  }

  String _nextFicha(KomandaState state) {
    var maxFicha = 0;
    for (final order in state.orders) {
      final value = int.tryParse(order.folio.trim());
      if (value != null && value > maxFicha) maxFicha = value;
    }
    return '${maxFicha + 1}';
  }

  Widget _totals(double productsTotal) {
    final fee = orderType == KomandaOrderType.delivery ? deliveryFee : 0.0;
    final total = productsTotal + fee;
    return KomandaCard(child: Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Productos', style: TextStyle(color: KomandaTheme.softText)), Text('\$ ${productsTotal.toStringAsFixed(2)}')]),
      if (fee > 0) ...[
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Envío a domicilio', style: TextStyle(color: KomandaTheme.softText)), Text('\$ ${fee.toStringAsFixed(2)}')]),
      ],
      const SizedBox(height: 8),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), Text('\$ ${total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: KomandaTheme.purple))]),
    ]));
  }

  Widget _navigation({required VoidCallback onBack, required VoidCallback? onNext}) => Padding(
    padding: const EdgeInsets.all(18),
    child: Row(children: [Expanded(child: OutlinedButton(onPressed: onBack, child: const Text('Atrás'))), const SizedBox(width: 12), Expanded(child: FilledButton(onPressed: onNext, child: const Text('Continuar')))]),
  );
}




class _SelectedCartItemCard extends StatelessWidget {
  final String cartKey;
  final KomandaOrderItem item;
  final VoidCallback onRemove;

  const _SelectedCartItemCard({
    required this.cartKey,
    required this.item,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: KomandaTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KomandaItemDetailView(item: item, showPrice: true),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: onRemove,
              icon: const Icon(Icons.remove_circle_outline_rounded, size: 18),
              label: const Text('Quitar uno'),
            ),
          ),
        ],
      ),
    );
  }
}

class _LargeCategoryFilter extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;

  const _LargeCategoryFilter({required this.text, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
          decoration: BoxDecoration(
            color: selected ? KomandaTheme.purple.withOpacity(.12) : Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? KomandaTheme.purple : KomandaTheme.border,
              width: selected ? 2 : 1,
            ),
          ),
          child: Text(
            text,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: selected ? KomandaTheme.purple : KomandaTheme.text,
            ),
          ),
        ),
      );
}

enum _MeatAmountMode { kilograms, money }

class _MeatAmountSelection {
  final double kilograms;
  final double amount;

  const _MeatAmountSelection({required this.kilograms, required this.amount});
}

class _AddProductConfiguration {
  final int quantity;
  final String note;
  const _AddProductConfiguration({required this.quantity, required this.note});
}

class _OrderTypeCard extends StatelessWidget {
  final bool selected;
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _OrderTypeCard({
    required this.selected,
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: selected ? KomandaTheme.purple.withOpacity(.09) : Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? KomandaTheme.purple : KomandaTheme.border,
              width: selected ? 2 : 1,
            ),
          ),
          child: Column(
            children: [
              Icon(icon, color: selected ? KomandaTheme.purple : KomandaTheme.softText, size: 31),
              const SizedBox(height: 9),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  title,
                  maxLines: 1,
                  style: const TextStyle(fontWeight: FontWeight.w900, color: KomandaTheme.text),
                ),
              ),
            ],
          ),
        ),
      );
}


class _PackageSelectionItem {
  final String productId;
  final String productName;
  final String slotLabel;

  const _PackageSelectionItem({
    required this.productId,
    required this.productName,
    required this.slotLabel,
  });
}

class _PackageCompositionSheet extends StatefulWidget {
  final KomandaProduct product;
  final List<KomandaProduct> allProducts;

  const _PackageCompositionSheet({
    required this.product,
    required this.allProducts,
  });

  @override
  State<_PackageCompositionSheet> createState() =>
      _PackageCompositionSheetState();
}

class _PackageCompositionSheetState extends State<_PackageCompositionSheet> {
  late final Map<String, Map<String, int>> counts;

  @override
  void initState() {
    super.initState();
    counts = {
      for (final group in widget.product.packageGroups)
        group.id: <String, int>{},
    };

    // Si un grupo tiene una única opción y cantidad fija, se llena solo.
    // Ejemplo: "Torta" -> solo existe el producto Tortas -> 1 requerida.
    for (final group in widget.product.packageGroups) {
      final exactQty = group.maxSelections != null &&
              group.maxSelections == group.minSelections
          ? group.maxSelections!
          : 0;
      if (group.optionDetails.length == 1 && exactQty > 0) {
        final option = group.optionDetails.first;
        counts[group.id]![_optionKey(option)] = exactQty;
      }
    }
  }

  String _optionKey(KomandaProductOption option) {
    if (option.linkedProductId.trim().isNotEmpty) {
      return 'id:${option.linkedProductId.trim()}';
    }
    return 'name:${option.label.trim().toLowerCase()}';
  }

  KomandaProduct? _linkedProduct(KomandaProductOption option) {
    if (option.linkedProductId.trim().isNotEmpty) {
      for (final p in widget.allProducts) {
        if (p.id == option.linkedProductId.trim()) return p;
      }
    }

    for (final p in widget.allProducts) {
      if (p.name.trim().toLowerCase() == option.label.trim().toLowerCase()) {
        return p;
      }
    }
    return null;
  }

  int totalFor(KomandaProductOptionGroup group) =>
      counts[group.id]!.values.fold(0, (a, b) => a + b);

  bool get valid => widget.product.packageGroups.every((group) {
        final count = totalFor(group);
        final min = group.minSelections > 0
            ? group.minSelections
            : (group.required ? 1 : 0);
        final max = group.maxSelections;
        return count >= min && (max == null || count <= max);
      });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * .92,
        ),
        decoration: const BoxDecoration(
          color: Color(0xFFF8F7FC),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44,
              height: 5,
              margin: const EdgeInsets.only(top: 10, bottom: 12),
              decoration: BoxDecoration(
                color: KomandaTheme.border,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 10, 12),
              child: Row(
                children: [
                  const CircleAvatar(
                    backgroundColor: Color(0xFFF1EAFF),
                    child: Icon(Icons.inventory_2_outlined,
                        color: KomandaTheme.purple),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.product.name,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            color: KomandaTheme.text,
                          ),
                        ),
                        const Text(
                          'Elige qué va dentro del paquete. Después te pediré los complementos de cada producto.',
                          style: TextStyle(
                            color: KomandaTheme.softText,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            Flexible(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                children: widget.product.packageGroups.map((group) {
                  final min = group.minSelections > 0
                      ? group.minSelections
                      : (group.required ? 1 : 0);
                  final max = group.maxSelections;
                  final current = totalFor(group);
                  final requirement = max != null && max == min
                      ? 'Debes elegir $max'
                      : max == null
                          ? 'Mínimo $min'
                          : 'Elige de $min a $max';

                  return KomandaCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                group.name,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  color: KomandaTheme.text,
                                ),
                              ),
                            ),
                            Text(
                              '$current / ${max ?? min}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                                color: KomandaTheme.purple,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          requirement,
                          style: const TextStyle(
                            fontSize: 11,
                            color: KomandaTheme.softText,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 10),
                        ...group.optionDetails.map((option) {
                          final key = _optionKey(option);
                          final amount = counts[group.id]![key] ?? 0;
                          final linked = _linkedProduct(option);
                          final groups = linked?.selectableOptionGroups ?? const <KomandaProductOptionGroup>[];
                          final hasOptions = groups.isNotEmpty;
                          final canAdd = max == null || current < max;

                          return Container(
                            margin: const EdgeInsets.only(bottom: 7),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: KomandaTheme.border),
                            ),
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 3,
                              ),
                              leading: CircleAvatar(
                                backgroundColor: hasOptions
                                    ? KomandaTheme.purple.withOpacity(.10)
                                    : const Color(0xFFF3F3F7),
                                child: Icon(
                                  hasOptions
                                      ? Icons.tune_rounded
                                      : Icons.restaurant_menu_rounded,
                                  color: hasOptions
                                      ? KomandaTheme.purple
                                      : KomandaTheme.softText,
                                ),
                              ),
                              title: Text(
                                option.label,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: KomandaTheme.text,
                                ),
                              ),
                              subtitle: hasOptions
                                  ? Text(
                                      'Después seleccionarás: ${groups.map((g) => g.name).join(' · ')}',
                                      style: const TextStyle(
                                        fontSize: 11,
                                        color: KomandaTheme.purple,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    )
                                  : const Text(
                                      'No requiere complementos adicionales',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: KomandaTheme.softText,
                                      ),
                                    ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    onPressed: amount <= 0
                                        ? null
                                        : () => setState(() {
                                              counts[group.id]![key] = amount - 1;
                                            }),
                                    icon: const Icon(Icons.remove_circle_outline),
                                  ),
                                  Text(
                                    '$amount',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: !canAdd
                                        ? null
                                        : () => setState(() {
                                              counts[group.id]![key] = amount + 1;
                                            }),
                                    icon: const Icon(Icons.add_circle_outline),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: !valid
                      ? null
                      : () {
                          final result = <_PackageSelectionItem>[];
                          for (final group in widget.product.packageGroups) {
                            final totalInGroup = totalFor(group);
                            var position = 0;
                            for (final option in group.optionDetails) {
                              final amount = counts[group.id]![
                                      _optionKey(option)] ??
                                  0;
                              for (var i = 0; i < amount; i++) {
                                position++;
                                result.add(
                                  _PackageSelectionItem(
                                    productId: option.linkedProductId,
                                    productName: option.label,
                                    slotLabel: totalInGroup > 1
                                        ? '${group.name} $position'
                                        : group.name,
                                  ),
                                );
                              }
                            }
                          }
                          Navigator.pop(context, result);
                        },
                  icon: const Icon(Icons.arrow_forward_rounded),
                  label: const Text(
                    'Continuar a seleccionar ingredientes',
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProductOptionsSheet extends StatefulWidget {
  final KomandaProduct product;
  final List<KomandaProduct> availableProducts;
  final List<String> initialSpecifications;
  final String? titleOverride;
  final String? subtitleOverride;

  const _ProductOptionsSheet({
    required this.product,
    this.availableProducts = const [],
    this.initialSpecifications = const [],
    this.titleOverride,
    this.subtitleOverride,
  });

  @override
  State<_ProductOptionsSheet> createState() => _ProductOptionsSheetState();
}

class _ProductOptionsSheetState extends State<_ProductOptionsSheet> {
  late final Map<String, Set<String>> selected;

  bool _allowsMultiple(KomandaProductOptionGroup group) => group.multiple;

  List<KomandaProductOption> _availableOptions(KomandaProductOptionGroup group) {
    if (group.optionDetails.isEmpty || widget.availableProducts.isEmpty) return group.optionDetails;
    return group.optionDetails.where((option) {
      final linkedId = option.linkedProductId.trim();
      if (linkedId.isNotEmpty) {
        final matches = widget.availableProducts.where((p) => p.id == linkedId);
        if (matches.isNotEmpty) return matches.first.available;
      }

      final optionName = option.label.trim().toLowerCase();
      final byName = widget.availableProducts.where(
        (p) => p.name.trim().toLowerCase() == optionName,
      );
      if (byName.isNotEmpty) return byName.first.available;

      return true;
    }).toList();
  }

  List<String> _availableLabels(KomandaProductOptionGroup group) {
    if (group.optionDetails.isEmpty) return group.options;
    return _availableOptions(group).map((option) => option.label).toList();
  }

  @override
  void initState() {
    super.initState();
    selected = {};
    for (final group in widget.product.selectableOptionGroups) {
      final matches = widget.initialSpecifications
          .map((value) {
            final prefix = '${group.name}: ';
            return value.startsWith(prefix) ? value.substring(prefix.length) : value;
          })
          .where((value) => _availableLabels(group).contains(value))
          .toSet();
      final availableLabels = _availableLabels(group);
      if (matches.isEmpty && group.required && availableLabels.isNotEmpty && group.minSelections <= 1) {
        matches.add(availableLabels.first);
      }
      selected[group.id] = matches;
    }
  }

  bool get isValid => widget.product.selectableOptionGroups.every((group) {
        final availableLabels = _availableLabels(group);
        if (group.required && availableLabels.isEmpty) return false;
        final values = (selected[group.id] ?? const <String>{}).where(availableLabels.contains).toSet();
        final min = group.required ? (group.minSelections <= 0 ? 1 : group.minSelections) : group.minSelections;
        final max = group.maxSelections;
        if (values.length < min) return false;
        if (max != null && max > 0 && values.length > max) return false;
        return true;
      });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * .88,
        ),
        decoration: const BoxDecoration(
          color: Color(0xFFF8F7FC),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44,
              height: 5,
              margin: const EdgeInsets.only(top: 10, bottom: 12),
              decoration: BoxDecoration(
                color: KomandaTheme.border,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 10, 12),
              child: Row(
                children: [
                  const CircleAvatar(
                    backgroundColor: Color(0xFFF1EAFF),
                    child: Icon(Icons.tune, color: KomandaTheme.purple),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.titleOverride ?? widget.product.printName,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            color: KomandaTheme.text,
                          ),
                        ),
                        Text(
                          widget.subtitleOverride ??
                              'Selecciona cómo debe prepararse este producto.',
                          style: const TextStyle(
                            color: KomandaTheme.softText,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Column(
                  children: widget.product.selectableOptionGroups.map((group) {
                    final values = selected[group.id] ?? <String>{};
                    return KomandaCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  group.name,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                    color: KomandaTheme.text,
                                  ),
                                ),
                              ),
                              Text(
                                _allowsMultiple(group) ? 'Puedes elegir varias' : 'Elige una',
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: KomandaTheme.softText,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _availableLabels(group).map((option) {
                              final active = values.contains(option);
                              return FilterChip(
                                selected: active,
                                label: Text(option),
                                onSelected: (_) {
                                  setState(() {
                                    final groupValues = selected[group.id] ?? <String>{};
                                    if (_allowsMultiple(group)) {
                                      if (active) {
                                        groupValues.remove(option);
                                      } else {
                                        final max = group.maxSelections;
                                        if (max == null || max <= 0 || groupValues.length < max) {
                                          groupValues.add(option);
                                        }
                                      }
                                    } else {
                                      groupValues
                                        ..clear()
                                        ..add(option);
                                    }
                                    selected[group.id] = groupValues;
                                  });
                                },
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: isValid
                      ? () {
                          final specifications = <String>[];
                          for (final group in widget.product.selectableOptionGroups) {
                            for (final value in selected[group.id] ?? const <String>{}) {
                              specifications.add('${group.name}: $value');
                            }
                          }
                          Navigator.pop(context, specifications);
                        }
                      : null,
                  icon: const Icon(Icons.add_shopping_cart),
                  label: const Text('Agregar con estas opciones'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TableOrderCard extends StatelessWidget {
  final KomandaOrder order;
  final bool active;
  final VoidCallback onTap;

  const _TableOrderCard({
    required this.order,
    required this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: active ? KomandaTheme.purple : KomandaTheme.border,
              width: active ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: active
                    ? KomandaTheme.purple.withOpacity(.10)
                    : const Color(0xFFF3F3F7),
                child: Icon(
                  active ? Icons.receipt_long : Icons.history,
                  color: active ? KomandaTheme.purple : KomandaTheme.softText,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Pedido #${order.shortFolio}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: KomandaTheme.text,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '${order.totalItems} productos · ${order.status.label}',
                      style: const TextStyle(
                        color: KomandaTheme.softText,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      '${order.createdAt.day.toString().padLeft(2, '0')}/'
                      '${order.createdAt.month.toString().padLeft(2, '0')}/'
                      '${order.createdAt.year} · '
                      '${order.createdAt.hour.toString().padLeft(2, '0')}:'
                      '${order.createdAt.minute.toString().padLeft(2, '0')}',
                      style: const TextStyle(
                        fontSize: 11,
                        color: KomandaTheme.softText,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '\$ ${order.total.toStringAsFixed(2)}',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: active ? KomandaTheme.green : KomandaTheme.text,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Icon(
                    Icons.chevron_right,
                    color: KomandaTheme.softText,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyTableOrderCard extends StatelessWidget {
  final String table;
  const _EmptyTableOrderCard({required this.table});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: KomandaTheme.border),
      ),
      child: Column(
        children: [
          const Icon(
            Icons.event_seat_outlined,
            size: 34,
            color: KomandaTheme.green,
          ),
          const SizedBox(height: 8),
          Text(
            '$table está disponible',
            style: const TextStyle(
              fontWeight: FontWeight.w900,
              color: KomandaTheme.text,
            ),
          ),
          const SizedBox(height: 3),
          const Text(
            'No se creará ningún pedido al tocar la mesa.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: KomandaTheme.softText,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _Progress extends StatelessWidget {
  final int current; const _Progress({required this.current});
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
    child: Row(children: List.generate(4, (i) => Expanded(child: Container(height: 5, margin: EdgeInsets.only(right: i == 3 ? 0 : 6), decoration: BoxDecoration(color: i <= current ? KomandaTheme.purple : KomandaTheme.border, borderRadius: BorderRadius.circular(10))))),
  ));
}

extension _KomandaFirstOrNull<E> on Iterable<E> {
  E? get firstOrNull => isEmpty ? null : first;
}
